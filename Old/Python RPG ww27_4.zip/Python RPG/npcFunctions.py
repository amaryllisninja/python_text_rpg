#NPC functions and actions
import gameNPCs as gN
import rooms, random, time, pickle, shelve

def getNPCType(npcName):
    npcType = gN.npcType[npcName]
    return npcType

def talk(npcName):
    talkList = gN.npcTalk[npcName]
    randNum = random.randint(0, len(talkList))
    print(talkList[randNum])
    
def interaction(npcName):
    npcType = getNPCType(npcName)
    greetStr = gN.npcGreeting[npcName]
    print(greetStr)

    #NPC interaction loop
    while True:
        print(gN.npcOptPrompt[npcType], end='  ')
        choice = input()
        choice = choice.lower()
        if choice in npcFunctions[npcType]:
            print("In progress...")
        else:
            print("You can\'t " + choice + " with " + npcName + ".")
            time.sleep(1)
