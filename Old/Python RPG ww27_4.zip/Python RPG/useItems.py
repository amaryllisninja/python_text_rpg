import random, time, pickle, shelve, rooms, gameActions
import gameItems as gI

def useItem(item):
   print("You use " + item + ".\n")
   pass


