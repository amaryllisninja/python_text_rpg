#Saved characters
names = {
    "bob",
    "joetheplumber",
    "solaire",
}
