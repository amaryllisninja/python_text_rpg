itemNames = {
    
}

itemDescriptions = {
    'short sword':'''A sword about one third the length of your body. It feels comfortable
in your hand.''',
    'dagger':'''A short blade with a hilt. There's nothing ornate about this dagger, but
it looks as though it will do some damage.'''
    'padded armour':'''Light weight, fabric armour that fits you comfortably, although is
getting a little warm for your tastes.''',
    'wizard robes':'''.'''
    'small shield':'''A small shield with a metal handle on the back. It looks like it
will only give you a little protection.'''
}

itemType = {
    
}
